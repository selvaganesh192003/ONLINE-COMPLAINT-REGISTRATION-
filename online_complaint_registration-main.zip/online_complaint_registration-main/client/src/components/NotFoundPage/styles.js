import { makeStyles } from '@material-ui/core/styles';

export default makeStyles((theme) => ({
  notFound: {
    width: '100%',
    height: '100%',
    textAlign: 'center',
    marginTop: '33.3%',
  }
}));
