import Auth from './Auth.js';

const AdminAuth = () => {
    return (
        <Auth admin={true}/>
     );
}

export default AdminAuth;